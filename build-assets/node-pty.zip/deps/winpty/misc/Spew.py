#!/usr/bin/env python
i = 0;
while True:
    i += 1
    print(i)
